# SimpleCalculator
A simple calculator written in Java and designed using JavaFX.
