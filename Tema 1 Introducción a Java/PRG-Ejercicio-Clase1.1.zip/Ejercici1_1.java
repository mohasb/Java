
/**
Realiza un aplicación Java que muestre por pantalla la tabla del 3, usando las estructura while
 */
public class Ejercici1_1
{
   public static void main(String [] args){
       final int MAX=10;
       int i=0;
       while(i<=MAX){
           System.out.println(i+"x3= "+i*3);
           i++;
           //System.out.println(3*i++);

        }
    
    
    }
    
    
}
