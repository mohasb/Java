
public class Tabla3
{
    public static void main(String[] args) {
        
        int tabla = 3;
        int multiplicador = 0;
        
        System.out.println("Tabla del 3: ");

        
        while (multiplicador <= 10) {
            
            System.out.println(tabla + " * " + multiplicador + " = " + (tabla * multiplicador));
            
            multiplicador++;
        }
    }
}
