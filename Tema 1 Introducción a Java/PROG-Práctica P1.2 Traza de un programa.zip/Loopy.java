
public class Loopy {
	public static void main (String [] arg ) {
		
		int x = 1;

		System.out.println("Antes del bucle");

		while (x < 4) {

		  System.out.println("En el bucle");

		  System.out.println("El valor de x es "  + x);

		  x = x + 1;

		}

		System.out.println("Despu�s del bucle");
	}
}
