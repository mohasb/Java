
public class Main
{
   public static void main(String[] args) {
       Persona uno = new Persona();
       uno.obtenDatos();
       uno.muestraDatos();
   }
}
