
public interface Calificar
{
    abstract void calificar();
}
