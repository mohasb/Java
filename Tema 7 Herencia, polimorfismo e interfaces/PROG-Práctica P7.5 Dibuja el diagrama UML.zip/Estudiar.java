
public interface Estudiar
{
    abstract void estudiar();
}
