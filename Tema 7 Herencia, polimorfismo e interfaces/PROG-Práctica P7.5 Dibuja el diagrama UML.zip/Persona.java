
abstract class Persona
{
    double altura;
    double peso;
    String sexo;
    
    abstract void existir();
}
