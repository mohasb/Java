
public class Cantante extends Persona implements PuedeCantar
{
    public void cantar() {
        System.out.println("El cantante canta: Do, Re, Mi, Fa, Sol, La, Si, Do");
    }
}
