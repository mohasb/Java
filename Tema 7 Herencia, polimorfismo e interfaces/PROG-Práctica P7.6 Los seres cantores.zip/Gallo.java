
public class Gallo extends Animal implements PuedeCantar
{
    public void cantar() {
        System.out.println("El gallo canta: Ki-ki-ri-kiiii");
    }
}
