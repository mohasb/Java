
public abstract class Animal
{
   
}
