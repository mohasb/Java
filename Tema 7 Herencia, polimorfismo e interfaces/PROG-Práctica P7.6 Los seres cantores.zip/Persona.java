public abstract class Persona
{
    
}
