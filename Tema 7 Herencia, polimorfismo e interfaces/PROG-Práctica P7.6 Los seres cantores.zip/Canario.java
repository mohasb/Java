
public class Canario extends Animal implements PuedeCantar
{
    public void cantar() {
        System.out.println("El canario canta: Pioo-Piooo");
    }
}
