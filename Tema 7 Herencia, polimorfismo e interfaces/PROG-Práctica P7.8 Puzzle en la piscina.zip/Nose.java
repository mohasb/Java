interface Nose {
    public int iMethod();
}
