class Acts extends Picasso {
    @Override
    public int iMethod() {
        return 5;
    }
}
