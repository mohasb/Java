class Clowns extends Picasso {
    @Override
    public int iMethod() {
        return 7;
    }
}
