abstract class Picasso implements Nose {
    @Override
    public int iMethod() {
        return 7;
    }
}
