package com.muhammad;

public class Rowboat extends Boat {
	
	public void rowTheBoat() {
		System.out.println("stroke natasha");
	}
	
}
