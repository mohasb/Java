public abstract class Persona extends SerVivo
{
    private int edad;
    
    public void setEdad(int edad) {this.edad = edad;}
    public int getEdad() {return edad;}
}