
public abstract class Animal extends SerVivo
{
   private int numPatas;
   
   public void setNumPatas(int numPatas) {this.numPatas = numPatas;}
   public int getnumPatas() {return numPatas;}
}
