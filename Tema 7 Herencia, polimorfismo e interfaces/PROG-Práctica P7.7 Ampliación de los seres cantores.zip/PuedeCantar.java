public interface PuedeCantar
{
   abstract void cantar();
}
