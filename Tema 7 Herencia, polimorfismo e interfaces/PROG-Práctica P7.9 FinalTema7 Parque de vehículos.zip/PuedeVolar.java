public interface PuedeVolar
{
    abstract String volar();
}
