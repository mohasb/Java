
public interface PuedeNavegar 
{
    abstract String navegar();
}
