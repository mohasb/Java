
public interface PuedeCircular
{
    abstract String circular();
}
