 

public class Monster {

	boolean frighten(int d) {
		System.out.println("arrrgh");
		return true;
	}

}
