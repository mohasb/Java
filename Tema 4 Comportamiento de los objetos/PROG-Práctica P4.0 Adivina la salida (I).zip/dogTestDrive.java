
public class dogTestDrive {
	public static void main(String[] args) {
		dog one = new dog();
		one.size = 70;
		
		dog two = new dog();
		two.size = 8;
		
		dog three = new dog();
		three.size = 35;
		
		
		one.bark();
		two.bark();
		three.bark();
		
		
	}
}
