
public class PoorDog
{
    private int size;
    private String name;
    
    public int getSize() {
        return size;
        //Este método devolverá 0
    }
    public String getName() {
        return name;
        //Este método devolverá null
    }
}
