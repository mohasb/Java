package muhammad;

import java.io.Serializable;

public class Carta implements Serializable {

    private String pregunta;
    private String respuesta;

    public Carta(String pregunta, String respuesta) {
        this.pregunta = pregunta;
        this.respuesta = respuesta;
    }



    public String getPregunta() {
        return pregunta;
    }
    public String getRespuesta() {
        return respuesta;
    }

    @Override
    public String toString() {
        return "Carta{" +
                "pregunta='" + pregunta + '\'' +
                ", respuesta='" + respuesta + '\'' +
                '}';
    }
}
