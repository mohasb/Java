
public class PFinalTema2
{
   public static void main(String[] args) {
       
       Alumno uno = new Alumno();
       uno.bienvenida();
       uno.obtenerNumAlumnos();
       uno.obtenerDatos();
       uno.despedida();
   }
}
