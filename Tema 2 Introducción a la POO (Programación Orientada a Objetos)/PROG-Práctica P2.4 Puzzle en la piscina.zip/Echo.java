
public class Echo
{
    int count = 0;
    void hello() {
        System.out.println("helloooo...");
    }
}
