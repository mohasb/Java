
public class TapeDeck
{
    boolean canRecord = false;
    
    void playTape() {
        System.out.println("Tape playing");
    }
    void recordTape() {
        System.out.println("Tape recording");
    }
}
