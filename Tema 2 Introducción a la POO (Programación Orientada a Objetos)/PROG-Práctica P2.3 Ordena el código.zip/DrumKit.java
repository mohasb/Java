
public class DrumKit
{
    boolean topHat = true;
    boolean snare = true;
    void playSnare() {
        System.out.println("bang bang ba-bang");
    }
    void playTopHat() {
       System.out.println("ding ding da-ding"); 
    }
}
