
public class SimpleGUI2B  {
    public static void main(String[] args) {
        Ventana ventana = new Ventana();
        ventana.setVisible(true);
        ventana.setBounds(200, 200, 400, 250);
    }

}
