public class SimpleGUI2 {
    public static void main(String[] args) {
        Ventana ventana = new Ventana();
        ventana.setBounds(200, 200, 400, 250);
        ventana.setVisible(true);
    }
}
